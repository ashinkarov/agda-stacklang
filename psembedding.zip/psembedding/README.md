Extracting the Power of Dependent Types: Supplementary Material
===============================================================

This archive contains the supplementary material for our submission
titled "Extracting the Power of Dependent Types" submitted to GPCE
2021. It contains the full code for the embedding and extractor
described in the paper, including the parts that were hidden from the
paper for a lack of space.

To check and use this code, you need Agda 2.6.2 and version 1.6 of the
Agda Standard library. Installation instructions can be found at
https://agda.readthedocs.io/en/v2.6.2/ and
https://github.com/agda/agda-stdlib/tree/v1.6 respectively.

The development is divided in several modules:

- preliminaries.agda contains re-exports all the definitions from the
  standard library that we use, and defines a few other general
  utility functions.

- embedding.agda defines the embedding of PostScript into Agda, as
  described in Section 3 of the paper.

- target-syntax.agda defines an AST of the target syntax and a
  pretty-printer for it, as described in section 4.1 of the paper.

- monad.agda defines the ExtractM monad as described in section 4.2 of
  the paper.

- pattern-synonyms.agda defines the pattern synonyms used in the
  implementation of the extractor.

- extraction.agda defines the extractor that extracts plain PostScript
  code from the embedding, as described in section 4.3 of the paper.

- tests.agda contains the examples given in the paper, plus tests that
  ensure the extraction process produces the expected result.

